# Databricks notebook source
# DBTITLE 1,Twitter Class for extracting a single keyword.
class Twitter:
    tweets = None
    query = None
    result_type = None
    count = None
    filename = None
    def __init__(self,query,result_type = 'normal',count = 50):
        self.query = query
        self.result_type = result_type
        self.count = count
        self.tweets = [status for status in tweepy.Cursor(api.search_tweets,self.query,tweet_mode = 'extended').items(self.count)]
        
    #Function for automatically printing tweets upon giving the list of tweepy objects as a parameters
    
    def Tweets(self):
        for tweet in self.tweets: 
            print('Full Text: ', tweet.full_text)
            print('Author Name: ',tweet.author.name)
            print('User Name: ',tweet.user.screen_name)
            print('Likes: ',tweet.favorite_count)
            print('Retweets: ',tweet.retweet_count)
            print('User Followers Count: ',tweet.user.followers_count)
            print('User Location: ',tweet.user.location)
            print('Total Tweets: ',tweet.user.statuses_count)
            print('User name created at: ',datetime.datetime.date(tweet.user.created_at)," ",datetime.datetime.time(tweet.user.created_at))
            print('Tweet posted at: ',datetime.datetime.date(tweet.created_at)," ",datetime.datetime.time(tweet.created_at))


            print(tweet.lang)


            if "media" in tweet.entities:

                print(tweet.entities['media'][0]['url'])
            elif tweet.entities['urls'] != []: 
                print(tweet.entities['urls'][0]['url'])
            else: 
                pass

            print('===================')
            
    #Function for getting the url of the tweet and the user
    
    
    def get_urls(self):
    #Get tweet urls from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}/status/{x.id}' for x in self.tweets]
    def get_tweets(self):
    #Get tweet texts from a list of tweepy objects.
        return [x.full_text for x in self.tweets]
    def get_tweet_time(self):
        #Get tweet creation time and date from a list of tweepy objects.
        return [tweet.created_at.strftime("%D %H:%M:%S") for tweet in self.tweets]
    def get_tweet_favorites(self):
        #Get tweet likes from a list of tweepy objects.
        z = []
        for x in self.tweets: 
            if 'retweeted_status' in x._json: 
                z.append(x.retweeted_status.favorite_count)
            else: 
                z.append(x.favorite_count)
        return z
    def get_tweet_retweets(self):
        #Get tweet retweets from a list of tweepy objects.
        return [tweet.retweet_count for tweet in self.tweets]
    def get_tweet_language(self):
        #Get tweet language from a list of tweepy objects.
        return [tweet.lang for tweet in self.tweets]
    def get_tweet_source(self):
        return [tweet.source for tweet in self.tweets]
    def get_usernames(self):
        #Get username of the twitter user from a list of tweepy objects.
        return [x.user.name for x in self.tweets]
    def get_userids(self):
        #Get userid of the twitter user from a list of tweepy objects.
        return [x.user.screen_name for x in self.tweets]
    def get_followers(self):
        #Get followers of the twitter user from a list of tweepy objects.
        return [x.user.followers_count for x in self.tweets]
    def get_total_tweets(self):
        #Get the total tweets of the twitter user from a list of tweepy objects.
        return [x.user.statuses_count for x in self.tweets]
    def get_user_location(self):
        #Get location of the twitter user from a list of tweepy objects.
        return [x.user.location for x in self.tweets]
    def user_name_creation(self):
        #Get joining date of the twitter user from a list of tweepy objects.
        return [tweet.user.created_at.strftime("%D %H:%M:%S") for tweet in self.tweets]
    def get_user_urls(self):
        #Get user url of the twitter user from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}' for x in self.tweets]
    def get_hashtags(self):
        #Get Hashtags of the tweet from a list of tweepy objects.
        return [", ".join(["#" +y[i]['text'] for i in range(len(y))]) for y in [x.entities['hashtags'] for x in self.tweets]]
    def get_mentions(self):
        #Get mentions of the tweet from a list of tweepy objects.
        return [", ".join(["@"+y['screen_name'] for y in x.entities['user_mentions']]) for x in self.tweets]
    def get_user_description(self):
        #Get total user desciption
        return [x.user.description for x in self.tweets]
    
    def to_dictionary(self):
        #Convert to dataframe
        a = self.get_tweets()
        b = self.get_urls()
        c = self.get_tweet_time()
        d = self.get_tweet_favorites()
        e = self.get_tweet_retweets()
        f = self.get_tweet_language()
        g = self.get_usernames()
        h = self.get_userids()
        j = self.get_followers()
        k = self.get_total_tweets()
        l = self.get_user_location()
        m = self.user_name_creation()
        n = self.get_user_urls()
        o = self.get_hashtags()
        p = self.get_mentions()
        q = self.get_user_description()
        r = self.get_tweet_source()

        TWEETS = []
        for i in range(len(a)):
            x = {}
            x['Tweet_Text'] = a[i]
            x['Tweet_URL'] = b[i]
            x['Tweet_Published_On'] = c[i]
            x['Tweet_Likes'] = d[i]
            x['Tweet_Retweets'] = e[i]
            x['Tweet_Language'] = f[i]
            x['Hashtags'] = o[i]
            x['Mentions'] = p[i]
            x['Name'] = g[i]
            x['Username']= h[i]
            x['Followers'] = j[i]
            x['Total_Tweets'] = k[i]
            x['User_Location'] = l[i]
            x['Joined_On'] = m[i]
            x['User_URL'] = n[i]
            x['User_Description'] = q[i]
            x['Source'] = r[i]   
            x['Search_Keyword'] = self.query
            TWEETS.append(x)

    
    
        return TWEETS       

# COMMAND ----------

# DBTITLE 1,Twitter class with multiple queries and the use of threads
class Twitter_thread:
    tweets = []
    query = None
    result_type = None
    count = None
    filename = None
    def __init__(self,query,result_type = 'normal',count = 50):
        self.tweets = []
        self.query = query
        self.result_type = result_type
        self.count = count
        with concurrent.futures.ThreadPoolExecutor() as executor: 
            results = executor.map(self.func,self.query)
        for result in results: 
            self.tweets.append(result)
    #Function for automatically printing tweets upon giving the list of tweepy objects as a parameters
    def func(self,q): 
        z= []
        for status in tweepy.Cursor(api.search_tweets,q,tweet_mode = 'extended').items(self.count):
            z.append(status)
        return [z,q]
    def Tweets(self, tweet_nest):
        for tweet in tweet_nest[0]: 
            print('Full Text: ', tweet.full_text)
            print('Author Name: ',tweet.author.name)
            print('User Name: ',tweet.user.screen_name)
            print('Likes: ',tweet.favorite_count)
            print('Retweets: ',tweet.retweet_count)
            print('User Followers Count: ',tweet.user.followers_count)
            print('User Location: ',tweet.user.location)
            print('Total Tweets: ',tweet.user.statuses_count)
            print('User name created at: ',datetime.datetime.date(tweet.user.created_at)," ",datetime.datetime.time(tweet.user.created_at))
            print('Tweet posted at: ',datetime.datetime.date(tweet.created_at)," ",datetime.datetime.time(tweet.created_at))


            print(tweet.lang)


            if "media" in tweet.entities:

                print(tweet.entities['media'][0]['url'])
            elif tweet.entities['urls'] != []: 
                print(tweet.entities['urls'][0]['url'])
            else: 
                pass

            print('===================')
            
    #Function for getting the url of the tweet and the user
    
    
    def get_urls(self, tweet_nest):
    #Get tweet urls from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}/status/{x.id}' for x in tweet_nest[0]]
    def get_tweets(self,tweet_nest):
    #Get tweet texts from a list of tweepy objects.
        return [x.full_text for x in tweet_nest[0]]
    def get_tweet_time(self,tweet_nest):
        #Get tweet creation time and date from a list of tweepy objects.
        return [tweet.created_at for tweet in tweet_nest[0]]
    def get_tweet_favorites(self,tweet_nest):
        #Get tweet likes from a list of tweepy objects.
        z = []
        for x in tweet_nest[0]: 
            if 'retweeted_status' in x._json: 
                z.append(x.retweeted_status.favorite_count)
            else: 
                z.append(x.favorite_count)
        return z
    def get_tweet_retweets(self,tweet_nest):
        #Get tweet retweets from a list of tweepy objects.
        return [tweet.retweet_count for tweet in tweet_nest[0]]
    def get_tweet_language(self,tweet_nest):
        #Get tweet language from a list of tweepy objects.
        return [tweet.lang for tweet in tweet_nest[0]]
    def get_tweet_source(self,tweet_nest):
        return [tweet.source for tweet in tweet_nest[0]]
    def get_usernames(self,tweet_nest):
        #Get username of the twitter user from a list of tweepy objects.
        return [x.user.name for x in tweet_nest[0]]
    def get_userids(self,tweet_nest):
        #Get userid of the twitter user from a list of tweepy objects.
        return [x.user.screen_name for x in tweet_nest[0]]
    def get_followers(self,tweet_nest):
        #Get followers of the twitter user from a list of tweepy objects.
        return [x.user.followers_count for x in tweet_nest[0]]
    def get_total_tweets(self,tweet_nest):
        #Get the total tweets of the twitter user from a list of tweepy objects.
        return [x.user.statuses_count for x in tweet_nest[0]]
    def get_user_location(self,tweet_nest):
        #Get location of the twitter user from a list of tweepy objects.
        return [x.user.location for x in tweet_nest[0]]
    def user_name_creation(self,tweet_nest):
        #Get joining date of the twitter user from a list of tweepy objects.
        return [tweet.user.created_at for tweet in tweet_nest[0]]
    def get_user_urls(self,tweet_nest):
        #Get user url of the twitter user from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}' for x in tweet_nest[0]]
    def get_hashtags(self,tweet_nest):
        #Get Hashtags of the tweet from a list of tweepy objects.
        return [", ".join(["#" +y[i]['text'] for i in range(len(y))]) for y in [x.entities['hashtags'] for x in tweet_nest[0]]]
    def get_mentions(self, tweet_nest):
        #Get mentions of the tweet from a list of tweepy objects.
        return [", ".join(["@"+y['screen_name'] for y in x.entities['user_mentions']]) for x in tweet_nest[0]]
    def get_user_description(self, tweet_nest):
        #Get total user desciption
        return [x.user.description for x in tweet_nest[0]]
    def keyword(self, tweet_nest): 
        return tweet_nest[1]
    
    def to_tuple(self):
        #Convert to dataframe
        TWEETS = []
        for x in self.tweets:
            a = self.get_tweets(x)
            b = self.get_urls(x)
            c = self.get_tweet_time(x)
            d = self.get_tweet_favorites(x)
            e = self.get_tweet_retweets(x)
            f = self.get_tweet_language(x)
            g = self.get_usernames(x)
            h = self.get_userids(x)
            j = self.get_followers(x)
            k = self.get_total_tweets(x)
            l = self.get_user_location(x)
            m = self.user_name_creation(x)
            n = self.get_user_urls(x)
            o = self.get_hashtags(x)
            p = self.get_mentions(x)
            q = self.get_user_description(x)
            r = self.get_tweet_source(x)
            s = self.keyword(x)
            for i in range(len(a)):
                x = []
                x.append(a[i])
                x.append(b[i])
                x.append(c[i])
                x.append(d[i])
                x.append(e[i])
                x.append(f[i])
                x.append(o[i])
                x.append(p[i])
                x.append(g[i])
                x.append(h[i])
                x.append(j[i])
                x.append(k[i])
                x.append(l[i])
                x.append(m[i])
                x.append(n[i])
                x.append(q[i])
                x.append(r[i])
                x.append(s)

                TWEETS.append(tuple(x))

    
    
        return TWEETS       

# COMMAND ----------

# DBTITLE 1,Converting a tuple data into a data frame using a schema
def Converter(tweets):
    #Converts the tuple into a dataframe.
    
    return spark.createDataFrame(data = tweets, schema = schema)

# COMMAND ----------

# DBTITLE 1,Twitter class with classic multiprocessing library.
class Twitter_processor_1:
    tweets = []
    query = None
    result_type = None
    count = None
    filename = None
    def __init__(self,query,result_type = 'normal',count = 50):
        self.tweets = []
        self.query = query
        self.result_type = result_type
        self.count = count
        processes = []
        pool = Pool(3)
        p = [pool.apply_async(self.func,args = (x,)) for x in self.query]
        for h in p: 
                self.tweets.append(h.get())
    #Function for automatically printing tweets upon giving the list of tweepy objects as a parameters
    def func(self,q): 
        z= []
        for status in tweepy.Cursor(api.search_tweets,q,tweet_mode = 'extended').items(self.count):
            z.append(status)
        return [z,q]
        
        print(len(self.tweets))
    def Tweets(self, tweet_nest):
        for tweet in tweet_nest[0]: 
            print('Full Text: ', tweet.full_text)
            print('Author Name: ',tweet.author.name)
            print('User Name: ',tweet.user.screen_name)
            print('Likes: ',tweet.favorite_count)
            print('Retweets: ',tweet.retweet_count)
            print('User Followers Count: ',tweet.user.followers_count)
            print('User Location: ',tweet.user.location)
            print('Total Tweets: ',tweet.user.statuses_count)
            print('User name created at: ',datetime.datetime.date(tweet.user.created_at)," ",datetime.datetime.time(tweet.user.created_at))
            print('Tweet posted at: ',datetime.datetime.date(tweet.created_at)," ",datetime.datetime.time(tweet.created_at))


            print(tweet.lang)


            if "media" in tweet.entities:

                print(tweet.entities['media'][0]['url'])
            elif tweet.entities['urls'] != []: 
                print(tweet.entities['urls'][0]['url'])
            else: 
                pass

            print('===================')
            
    #Function for getting the url of the tweet and the user
    
    
    def get_urls(self, tweet_nest):
    #Get tweet urls from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}/status/{x.id}' for x in tweet_nest[0]]
    def get_tweets(self,tweet_nest):
    #Get tweet texts from a list of tweepy objects.
        return [x.full_text for x in tweet_nest[0]]
    def get_tweet_time(self,tweet_nest):
        #Get tweet creation time and date from a list of tweepy objects.
        return [tweet.created_at for tweet in tweet_nest[0]]
    def get_tweet_favorites(self,tweet_nest):
        #Get tweet likes from a list of tweepy objects.
        z = []
        for x in tweet_nest[0]: 
            if 'retweeted_status' in x._json: 
                z.append(x.retweeted_status.favorite_count)
            else: 
                z.append(x.favorite_count)
        return z
    def get_tweet_retweets(self,tweet_nest):
        #Get tweet retweets from a list of tweepy objects.
        return [tweet.retweet_count for tweet in tweet_nest[0]]
    def get_tweet_language(self,tweet_nest):
        #Get tweet language from a list of tweepy objects.
        return [tweet.lang for tweet in tweet_nest[0]]
    def get_tweet_source(self,tweet_nest):
        return [tweet.source for tweet in tweet_nest[0]]
    def get_usernames(self,tweet_nest):
        #Get username of the twitter user from a list of tweepy objects.
        return [x.user.name for x in tweet_nest[0]]
    def get_userids(self,tweet_nest):
        #Get userid of the twitter user from a list of tweepy objects.
        return [x.user.screen_name for x in tweet_nest[0]]
    def get_followers(self,tweet_nest):
        #Get followers of the twitter user from a list of tweepy objects.
        return [x.user.followers_count for x in tweet_nest[0]]
    def get_total_tweets(self,tweet_nest):
        #Get the total tweets of the twitter user from a list of tweepy objects.
        return [x.user.statuses_count for x in tweet_nest[0]]
    def get_user_location(self,tweet_nest):
        #Get location of the twitter user from a list of tweepy objects.
        return [x.user.location for x in tweet_nest[0]]
    def user_name_creation(self,tweet_nest):
        #Get joining date of the twitter user from a list of tweepy objects.
        return [tweet.user.created_at for tweet in tweet_nest[0]]
    def get_user_urls(self,tweet_nest):
        #Get user url of the twitter user from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}' for x in tweet_nest[0]]
    def get_hashtags(self,tweet_nest):
        #Get Hashtags of the tweet from a list of tweepy objects.
        return [", ".join(["#" +y[i]['text'] for i in range(len(y))]) for y in [x.entities['hashtags'] for x in tweet_nest[0]]]
    def get_mentions(self, tweet_nest):
        #Get mentions of the tweet from a list of tweepy objects.
        return [", ".join(["@"+y['screen_name'] for y in x.entities['user_mentions']]) for x in tweet_nest[0]]
    def get_user_description(self, tweet_nest):
        #Get total user desciption
        return [x.user.description for x in tweet_nest[0]]
    def keyword(self, tweet_nest): 
        return tweet_nest[1]
    
    def to_tuple(self):
        #Convert to dataframe
        TWEETS = []
        for x in self.tweets:
            a = self.get_tweets(x)
            b = self.get_urls(x)
            c = self.get_tweet_time(x)
            d = self.get_tweet_favorites(x)
            e = self.get_tweet_retweets(x)
            f = self.get_tweet_language(x)
            g = self.get_usernames(x)
            h = self.get_userids(x)
            j = self.get_followers(x)
            k = self.get_total_tweets(x)
            l = self.get_user_location(x)
            m = self.user_name_creation(x)
            n = self.get_user_urls(x)
            o = self.get_hashtags(x)
            p = self.get_mentions(x)
            q = self.get_user_description(x)
            r = self.get_tweet_source(x)
            s = self.keyword(x)
            for i in range(len(a)):
                x = []
                x.append(a[i])
                x.append(b[i])
                x.append(c[i])
                x.append(d[i])
                x.append(e[i])
                x.append(f[i])
                x.append(o[i])
                x.append(p[i])
                x.append(g[i])
                x.append(h[i])
                x.append(j[i])
                x.append(k[i])
                x.append(l[i])
                x.append(m[i])
                x.append(n[i])
                x.append(q[i])
                x.append(r[i])
                x.append(s)

                TWEETS.append(tuple(x))

    
    
        return TWEETS       

# COMMAND ----------

# DBTITLE 1,Twitter Class with concurrent.futures multiprocessing module
class Twitter_processor:
    tweets = []
    query = None
    result_type = None
    count = None
    filename = None
    def __init__(self,query,result_type = 'normal',count = 50):
        self.tweets = []
        self.query = query
        self.result_type = result_type
        self.count = count
        with concurrent.futures.ProcessPoolExecutor() as executor: 
            results = executor.map(self.func,self.query)
        for result in results: 
            self.tweets.append(result)
    #Function for automatically printing tweets upon giving the list of tweepy objects as a parameters
    def func(self,q): 
        z= []
        for status in tweepy.Cursor(api.search_tweets,q,tweet_mode = 'extended').items(self.count):
            z.append(status)
        return [z,q]
    def Tweets(self, tweet_nest):
        for tweet in tweet_nest[0]: 
            print('Full Text: ', tweet.full_text)
            print('Author Name: ',tweet.author.name)
            print('User Name: ',tweet.user.screen_name)
            print('Likes: ',tweet.favorite_count)
            print('Retweets: ',tweet.retweet_count)
            print('User Followers Count: ',tweet.user.followers_count)
            print('User Location: ',tweet.user.location)
            print('Total Tweets: ',tweet.user.statuses_count)
            print('User name created at: ',datetime.datetime.date(tweet.user.created_at)," ",datetime.datetime.time(tweet.user.created_at))
            print('Tweet posted at: ',datetime.datetime.date(tweet.created_at)," ",datetime.datetime.time(tweet.created_at))


            print(tweet.lang)


            if "media" in tweet.entities:

                print(tweet.entities['media'][0]['url'])
            elif tweet.entities['urls'] != []: 
                print(tweet.entities['urls'][0]['url'])
            else: 
                pass

            print('===================')
            
    #Function for getting the url of the tweet and the user
    
    
    def get_urls(self, tweet_nest):
    #Get tweet urls from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}/status/{x.id}' for x in tweet_nest[0]]
    def get_tweets(self,tweet_nest):
    #Get tweet texts from a list of tweepy objects.
        return [x.full_text for x in tweet_nest[0]]
    def get_tweet_time(self,tweet_nest):
        #Get tweet creation time and date from a list of tweepy objects.
        return [tweet.created_at for tweet in tweet_nest[0]]
    def get_tweet_favorites(self,tweet_nest):
        #Get tweet likes from a list of tweepy objects.
        z = []
        for x in tweet_nest[0]: 
            if 'retweeted_status' in x._json: 
                z.append(x.retweeted_status.favorite_count)
            else: 
                z.append(x.favorite_count)
        return z
    def get_tweet_retweets(self,tweet_nest):
        #Get tweet retweets from a list of tweepy objects.
        return [tweet.retweet_count for tweet in tweet_nest[0]]
    def get_tweet_language(self,tweet_nest):
        #Get tweet language from a list of tweepy objects.
        return [tweet.lang for tweet in tweet_nest[0]]
    def get_tweet_source(self,tweet_nest):
        return [tweet.source for tweet in tweet_nest[0]]
    def get_usernames(self,tweet_nest):
        #Get username of the twitter user from a list of tweepy objects.
        return [x.user.name for x in tweet_nest[0]]
    def get_userids(self,tweet_nest):
        #Get userid of the twitter user from a list of tweepy objects.
        return [x.user.screen_name for x in tweet_nest[0]]
    def get_followers(self,tweet_nest):
        #Get followers of the twitter user from a list of tweepy objects.
        return [x.user.followers_count for x in tweet_nest[0]]
    def get_total_tweets(self,tweet_nest):
        #Get the total tweets of the twitter user from a list of tweepy objects.
        return [x.user.statuses_count for x in tweet_nest[0]]
    def get_user_location(self,tweet_nest):
        #Get location of the twitter user from a list of tweepy objects.
        return [x.user.location for x in tweet_nest[0]]
    def user_name_creation(self,tweet_nest):
        #Get joining date of the twitter user from a list of tweepy objects.
        return [tweet.user.created_at for tweet in tweet_nest[0]]
    def get_user_urls(self,tweet_nest):
        #Get user url of the twitter user from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}' for x in tweet_nest[0]]
    def get_hashtags(self,tweet_nest):
        #Get Hashtags of the tweet from a list of tweepy objects.
        return [", ".join(["#" +y[i]['text'] for i in range(len(y))]) for y in [x.entities['hashtags'] for x in tweet_nest[0]]]
    def get_mentions(self, tweet_nest):
        #Get mentions of the tweet from a list of tweepy objects.
        return [", ".join(["@"+y['screen_name'] for y in x.entities['user_mentions']]) for x in tweet_nest[0]]
    def get_user_description(self, tweet_nest):
        #Get total user desciption
        return [x.user.description for x in tweet_nest[0]]
    def keyword(self, tweet_nest): 
        return tweet_nest[1]
    
    def to_tuple(self):
        #Convert to dataframe
        TWEETS = []
        for x in self.tweets:
            a = self.get_tweets(x)
            b = self.get_urls(x)
            c = self.get_tweet_time(x)
            d = self.get_tweet_favorites(x)
            e = self.get_tweet_retweets(x)
            f = self.get_tweet_language(x)
            g = self.get_usernames(x)
            h = self.get_userids(x)
            j = self.get_followers(x)
            k = self.get_total_tweets(x)
            l = self.get_user_location(x)
            m = self.user_name_creation(x)
            n = self.get_user_urls(x)
            o = self.get_hashtags(x)
            p = self.get_mentions(x)
            q = self.get_user_description(x)
            r = self.get_tweet_source(x)
            s = self.keyword(x)
            for i in range(len(a)):
                x = []
                x.append(a[i])
                x.append(b[i])
                x.append(c[i])
                x.append(d[i])
                x.append(e[i])
                x.append(f[i])
                x.append(o[i])
                x.append(p[i])
                x.append(g[i])
                x.append(h[i])
                x.append(j[i])
                x.append(k[i])
                x.append(l[i])
                x.append(m[i])
                x.append(n[i])
                x.append(q[i])
                x.append(r[i])
                x.append(s)

                TWEETS.append(tuple(x))

    
    
        return TWEETS       

# COMMAND ----------

# DBTITLE 1,Twitter class with joblib multiprocessing module
class Twitter_joblib:
    tweets = []
    query = None
    result_type = None
    count = None
    filename = None
    def __init__(self,query,result_type = 'normal',count = 50):
        self.tweets = []
        self.query = query
        self.result_type = result_type
        self.count = count
        self.tweets = Parallel(n_jobs = -1)(delayed(self.func)(q) for q in self.query)
    #Function for automatically printing tweets upon giving the list of tweepy objects as a parameters
    def func(self,q): 
        z= []
        for status in tweepy.Cursor(api.search_tweets,q,tweet_mode = 'extended').items(self.count):
            z.append(status)
        return [z,q]
    def Tweets(self, tweet_nest):
        for tweet in tweet_nest[0]: 
            print('Full Text: ', tweet.full_text)
            print('Author Name: ',tweet.author.name)
            print('User Name: ',tweet.user.screen_name)
            print('Likes: ',tweet.favorite_count)
            print('Retweets: ',tweet.retweet_count)
            print('User Followers Count: ',tweet.user.followers_count)
            print('User Location: ',tweet.user.location)
            print('Total Tweets: ',tweet.user.statuses_count)
            print('User name created at: ',datetime.datetime.date(tweet.user.created_at)," ",datetime.datetime.time(tweet.user.created_at))
            print('Tweet posted at: ',datetime.datetime.date(tweet.created_at)," ",datetime.datetime.time(tweet.created_at))


            print(tweet.lang)


            if "media" in tweet.entities:

                print(tweet.entities['media'][0]['url'])
            elif tweet.entities['urls'] != []: 
                print(tweet.entities['urls'][0]['url'])
            else: 
                pass

            print('===================')
            
    #Function for getting the url of the tweet and the user
    
    
    def get_urls(self, tweet_nest):
    #Get tweet urls from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}/status/{x.id}' for x in tweet_nest[0]]
    def get_tweets(self,tweet_nest):
    #Get tweet texts from a list of tweepy objects.
        return [x.full_text for x in tweet_nest[0]]
    def get_tweet_time(self,tweet_nest):
        #Get tweet creation time and date from a list of tweepy objects.
        return [tweet.created_at for tweet in tweet_nest[0]]
    def get_tweet_favorites(self,tweet_nest):
        #Get tweet likes from a list of tweepy objects.
        z = []
        for x in tweet_nest[0]: 
            if 'retweeted_status' in x._json: 
                z.append(x.retweeted_status.favorite_count)
            else: 
                z.append(x.favorite_count)
        return z
    def get_tweet_retweets(self,tweet_nest):
        #Get tweet retweets from a list of tweepy objects.
        return [tweet.retweet_count for tweet in tweet_nest[0]]
    def get_tweet_language(self,tweet_nest):
        #Get tweet language from a list of tweepy objects.
        return [tweet.lang for tweet in tweet_nest[0]]
    def get_tweet_source(self,tweet_nest):
        return [tweet.source for tweet in tweet_nest[0]]
    def get_usernames(self,tweet_nest):
        #Get username of the twitter user from a list of tweepy objects.
        return [x.user.name for x in tweet_nest[0]]
    def get_userids(self,tweet_nest):
        #Get userid of the twitter user from a list of tweepy objects.
        return [x.user.screen_name for x in tweet_nest[0]]
    def get_followers(self,tweet_nest):
        #Get followers of the twitter user from a list of tweepy objects.
        return [x.user.followers_count for x in tweet_nest[0]]
    def get_total_tweets(self,tweet_nest):
        #Get the total tweets of the twitter user from a list of tweepy objects.
        return [x.user.statuses_count for x in tweet_nest[0]]
    def get_user_location(self,tweet_nest):
        #Get location of the twitter user from a list of tweepy objects.
        return [x.user.location for x in tweet_nest[0]]
    def user_name_creation(self,tweet_nest):
        #Get joining date of the twitter user from a list of tweepy objects.
        return [tweet.user.created_at for tweet in tweet_nest[0]]
    def get_user_urls(self,tweet_nest):
        #Get user url of the twitter user from a list of tweepy objects.
        return [f'https://twitter.com/{x.user.screen_name}' for x in tweet_nest[0]]
    def get_hashtags(self,tweet_nest):
        #Get Hashtags of the tweet from a list of tweepy objects.
        return [", ".join(["#" +y[i]['text'] for i in range(len(y))]) for y in [x.entities['hashtags'] for x in tweet_nest[0]]]
    def get_mentions(self, tweet_nest):
        #Get mentions of the tweet from a list of tweepy objects.
        return [", ".join(["@"+y['screen_name'] for y in x.entities['user_mentions']]) for x in tweet_nest[0]]
    def get_user_description(self, tweet_nest):
        #Get total user desciption
        return [x.user.description for x in tweet_nest[0]]
    def keyword(self, tweet_nest): 
        return tweet_nest[1]
    
    def to_tuple(self):
        #Convert to dataframe
        TWEETS = []
        for x in self.tweets:
            a = self.get_tweets(x)
            b = self.get_urls(x)
            c = self.get_tweet_time(x)
            d = self.get_tweet_favorites(x)
            e = self.get_tweet_retweets(x)
            f = self.get_tweet_language(x)
            g = self.get_usernames(x)
            h = self.get_userids(x)
            j = self.get_followers(x)
            k = self.get_total_tweets(x)
            l = self.get_user_location(x)
            m = self.user_name_creation(x)
            n = self.get_user_urls(x)
            o = self.get_hashtags(x)
            p = self.get_mentions(x)
            q = self.get_user_description(x)
            r = self.get_tweet_source(x)
            s = self.keyword(x)
            for i in range(len(a)):
                x = []
                x.append(a[i])
                x.append(b[i])
                x.append(c[i])
                x.append(d[i])
                x.append(e[i])
                x.append(f[i])
                x.append(o[i])
                x.append(p[i])
                x.append(g[i])
                x.append(h[i])
                x.append(j[i])
                x.append(k[i])
                x.append(l[i])
                x.append(m[i])
                x.append(n[i])
                x.append(q[i])
                x.append(r[i])
                x.append(s)

                TWEETS.append(tuple(x))

    
    
        return TWEETS       