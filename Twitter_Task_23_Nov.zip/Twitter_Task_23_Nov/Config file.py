# Databricks notebook source
# DBTITLE 1,Importing all the libraries
import tweepy
import datetime
import ast
import csv
import time
from threading import *
from multiprocessing import *
from pyspark.sql.types import StructType,StructField, StringType, IntegerType, DateType
import concurrent.futures
from joblib import Parallel, delayed

# COMMAND ----------

# DBTITLE 1,Using all the api keys to start the API.
api_key = 'Qf3b8es3yxPbI9tIFt3jmOKUC'
api_key_secret = 'BtqEAMmIqghHwzP2itBrtPEPFiowqTNxaqo7Agv2lnV6UC3Q1r'
bearer = 'AAAAAAAAAAAAAAAAAAAAAI2TggEAAAAAbtYvuwHt0G9ehH2YIlqcXhRM988%3DtIuvY2emwqp71OFMefzhiCLvSzv1BcmVgRXrytCGFyGM3O1qKF'
access_token = '796207871692251137-RaMUHU1XhZsnk3GoDgRaWPemwdePKLQ'
access_token_secret = 'QJkLFDFXTtPtRplsKM2ERILP872G9wKP9xSeBH7POxYZc'

# COMMAND ----------

# DBTITLE 1,Authentication
auth = tweepy.OAuth1UserHandler(api_key, api_key_secret, access_token, access_token_secret

)
api = tweepy.API(auth)

# COMMAND ----------

# DBTITLE 1,Making a Schema
schema = StructType([\
                        StructField('Tweet_Text',StringType(),True),\
                        StructField('Tweet_URL',StringType(),True),\
                        StructField('Tweet_Published_On', DateType(),True),\
                        StructField('Tweet_Likes',IntegerType(),True),\
                        StructField('Tweet_Retweets',IntegerType(),True),\
                        StructField('Tweet_Language',StringType(),True),\
                        StructField('Hashtags',StringType(),True),\
                        StructField('Mentions',StringType(),True),\
                        StructField('Name',StringType(),True),\
                        StructField('Username',StringType(),True),\
                        StructField('Followers',IntegerType(),True),\
                        StructField('Total_Tweets',IntegerType(),True),\
                        StructField('User_Location',StringType(),True),\
                        StructField('Joined_On',DateType(),True),\
                        StructField('User_URL',StringType(),True),\
                        StructField('User_Description',StringType(),True),\
                        StructField('Source',StringType(),True),\
                        StructField('Search_Keyword',StringType(),True)])