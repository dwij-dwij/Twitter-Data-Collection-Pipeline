# Databricks notebook source
# DBTITLE 1,Importing Config File
# MAGIC %run "./Config file"

# COMMAND ----------

# DBTITLE 1,Running the Function file
# MAGIC %run "./Function File"

# COMMAND ----------

# DBTITLE 1,Running the twitter api with Threads: 7 seconds running time
start_time = time.perf_counter()
a = Twitter_thread(['FIFA','Ronaldo','APOLOGIZE TO LISA','Kardashian'])
b = Converter(a.to_tuple())
display(b)
end_time= time.perf_counter()
print(end_time- start_time)


# COMMAND ----------

# DBTITLE 1,Obtaining Schema
b.printSchema()

# COMMAND ----------

# DBTITLE 1,Verifying the number of row data for each keyword.
b.filter(b.Search_Keyword == 'FIFA').count()
# VERIFYING THE NUMBER OF ROW DATA FOR EACH KEYWORD

# COMMAND ----------

# DBTITLE 1,Same as above with the keyword "Ronaldo"
b.filter(b.Search_Keyword == 'Ronaldo').count()

# COMMAND ----------

# DBTITLE 1,Running the Twitter API with concurrent.futures: 3 seconds
start_time = time.perf_counter()
raw_data = Twitter_processor(['FIFA','Ronaldo','APOLOGIZE TO LISA','Kardashian'])
final_data = Converter(raw_data.to_tuple())
display(final_data)
end_time = time.perf_counter()
print(end_time-start_time)

# COMMAND ----------

# DBTITLE 1,Running with Joblib multiprocessing library: 4 seconds
start_time = time.perf_counter()
raw_data_1 = Twitter_joblib(['FIFA','Ronaldo','APOLOGIZE TO LISA','Kardashian'])
final_data_1 = Converter(raw_data_1.to_tuple())
display(final_data_1)
end_time = time.perf_counter()
print(end_time - start_time)

# COMMAND ----------

# DBTITLE 1,Running with the classical asynchronize function in Multiprocessing library: 2.5 seconds
start_time = time.perf_counter()
raw_data_1 = Twitter_processor_1(['FIFA','Ronaldo','APOLOGIZE TO LISA','Kardashian'])
final_data_1 = Converter(raw_data_1.to_tuple())
print('Completed')
display(final_data_1)
end_time = time.perf_counter()
print(end_time - start_time)

# COMMAND ----------

# DBTITLE 1,Code on a single core: 6.5 seconds
start_time = time.perf_counter()
twitter= spark.createDataFrame(data = spark.sparkContext.emptyRDD(),schema = schema)
for x in ['FIFA','Ronaldo','APOLOGIZE TO LISA','Kardashian']:
    y = Twitter(x).to_dictionary()
    z = spark.createDataFrame(y)
    twitter = twitter.union(z)
display(twitter)
end_time = time.perf_counter()
print(end_time - start_time)
